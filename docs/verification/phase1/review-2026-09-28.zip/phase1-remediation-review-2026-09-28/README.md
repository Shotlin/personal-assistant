# Phase 1 remediation review package

Start with `00_VERDICT.md`. Phase 1 is **NOT COMPLETE / NOT ACCEPTED**.

- `01_FINDINGS.md`: remaining defects and exact source locations.
- `02_PHASE1_REPAIR_PLAN.md`: proposed C01–C10 corrective completion.
- `03_PHASE1_ONLY_AGENT_PROMPT.md`: copy into an implementation chat only after owner approval.
- `04_VERIFICATION.md`: methods and limitations.
- `evidence/`: independent source binding, 226-test JUnit, twelve probes, empty-live-case demonstration and static outputs.
- `context/original-planning/`: original full planning package, including all four original inputs.
- `context/prior-review/`: unchanged prior findings, complete coverage matrix, correction plan and evidence.
- `context/submitted-remediation/`: unchanged handoff and submitted gates reviewed here.

Historical context files retain their original paths, claims, manifests and timestamps. Their presence does not mean their claims are accepted. Current verdict and independent evidence take precedence for this review; actual source is identified by the manifest and must be inspected before editing. No Phase 2/3 implementation or deep planning is authorized.

`PACKAGE_MANIFEST.json` hashes all package files other than itself.
